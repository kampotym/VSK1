package com.finance.financeai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceAiAssistantApplicationTests {

    @Test
    void contextLoads() {
    }

}
