package com.finance.financeai;

public class Categorizer {

    public static String categorize(String text){

        text = text.toLowerCase();

        if(text.contains("uber") || text.contains("taxi"))
            return "Transport";

        if(text.contains("mcdonald") || text.contains("restaurant"))
            return "Food";

        if(text.contains("netflix"))
            return "Entertainment";

        if(text.contains("amazon"))
            return "Shopping";

        return "Other";
    }

}