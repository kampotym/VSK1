package com.finance.financeai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.awt.Desktop;
import java.net.URI;

@SpringBootApplication
public class FinanceAiAssistantApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinanceAiAssistantApplication.class, args);

        // 🔥 автоматты браузер ашу

    }
}