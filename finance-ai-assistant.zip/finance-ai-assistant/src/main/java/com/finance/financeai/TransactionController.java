package com.finance.financeai;

import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;

@RestController
@CrossOrigin
public class TransactionController {

    private final TransactionRepository repo;

    public TransactionController(TransactionRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/transactions")
    public Transaction add(@RequestBody Transaction t) {

        t.setCategory(categorize(t.getDescription()));

        if (t.getAmount() > 0) {
            t.setType("income");
        } else {
            t.setType("expense");
        }

        // 🔥 date қосу
        t.setDate(LocalDate.now());

        return repo.save(t);
    }

    @GetMapping("/transactions")
    public List<Transaction> all() {
        return repo.findAll();
    }

    // 🔥 CATEGORY SUMMARY
    @GetMapping("/transactions/summary")
    public Map<String, Integer> summary() {

        List<Transaction> list = repo.findAll();
        Map<String, Integer> result = new HashMap<>();

        for (Transaction t : list) {
            result.put(
                    t.getCategory(),
                    result.getOrDefault(t.getCategory(), 0) + t.getAmount()
            );
        }

        return result;
    }

    // 🔥 MONTHLY SUMMARY
    @GetMapping("/transactions/monthly")
    public Map<String, Integer> monthly() {

        List<Transaction> list = repo.findAll();
        Map<String, Integer> result = new HashMap<>();

        for (Transaction t : list) {

            if (t.getDate() == null) continue; // 🔥 БҰЛ МАҢЫЗДЫ

            String month = t.getDate().getMonth().toString();

            result.put(
                    month,
                    result.getOrDefault(month, 0) + t.getAmount()
            );
        }

        return result;
    }

    private String categorize(String desc) {
        desc = desc.toLowerCase();

        if (desc.contains("uber") || desc.contains("taxi"))
            return "Transport";
        if (desc.contains("food") || desc.contains("cafe"))
            return "Food";
        if (desc.contains("shop"))
            return "Shopping";

        return "Other";
    }
}